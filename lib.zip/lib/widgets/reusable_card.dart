import 'package:flutter/material.dart';

import '../assets/const.dart';

class ReusableCard extends StatelessWidget {
 
  final Color color;
  final Widget widget;
  

  const ReusableCard({
    Key? key, required this.color,
    required this.widget,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: kInactiveCardColor,
        borderRadius: BorderRadius.circular(15)
      ),
      child: widget,
    );
  }
}

