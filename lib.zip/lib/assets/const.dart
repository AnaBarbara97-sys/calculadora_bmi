import 'package:flutter/material.dart';

//paleta de colores 

const kPrimaryColor = Color(0xffDC25AA);
const kSecondaryColor = Color(0xffFF3D87);

//paleta para cartas 
const kActiveCardColor = Color(0xffFF6D68);
const kInactiveCardColor = Color(0xffFF9F52);
const kBottonCardColor = Color(0xffFFCD52);
const kBoxMainColor = Color(0xffFF4868);

//Propiedades de las cartas 
const kBottonCardHeight = 80.0;

const kCardStyle = TextStyle(
  color: Colors.white,
  fontSize: 20,
  fontWeight: FontWeight.bold
);