import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class DrawerInfo extends StatelessWidget {
  const DrawerInfo({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
     appBar: AppBar(
       title: const Text('Datos del desarrollador'),
     ),
     backgroundColor: Colors.purple.shade200,
     body: Column(
       children: [
         Center(
           child: Container(
             margin: const EdgeInsets.only(top: 20),
             width: 200,
             height: 200,
             decoration: BoxDecoration(
               color: Colors.pink,
               borderRadius: BorderRadius.circular(100),
             ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(100),
              child: Center(
                child: Image.asset('assets/images/perfil.jpg',),
                ),
            ),
           ),
         ),
         Container(
           padding: const EdgeInsets.only(top: 20),
           child: const Text(
             'Desarrolladora de móviles',
             style: TextStyle(
               fontSize: 20,
               color: Colors.white,
               fontWeight: FontWeight.bold,
               fontStyle: FontStyle.italic,
             ),
           ),
         ),
          Container( 
          alignment: Alignment.centerLeft,
           padding: const EdgeInsets.all(30),
           child: const Text(
             'Nombre: Ana Bárbara Zamora Sánchez',
             style: TextStyle(
               fontSize: 15,
               color: Colors.white,
               fontWeight: FontWeight.bold,
             ),
           ),
         ),
         Container( 
          alignment: Alignment.centerLeft,
           padding: const EdgeInsets.all(30),
           child: const Text(
             'Edad: 25 años',
             style: TextStyle(
               fontSize: 15,
               color: Colors.white,
               fontWeight: FontWeight.bold,
             ),
           ),
         ),
          Container( 
          alignment: Alignment.centerLeft,
           padding: const EdgeInsets.all(30),
           child: const Text(
             'Carrera: Ingeniería en Sistemas Computacionales',
             style: TextStyle(
               fontSize: 15,
               color: Colors.white,
               fontWeight: FontWeight.bold,
             ),
           ),
         ),

          Container( 
          alignment: Alignment.centerLeft,
           padding: const EdgeInsets.all(30),
           child: const Text(
             'Especialidad: Desarrollo de Software',
             style: TextStyle(
               fontSize: 15,
               color: Colors.white,
               fontWeight: FontWeight.bold,
             ),
           ),
         ),

         Container(
           height: 5,
           width: 300,
           color: Colors.orange.shade200,
         ),

        const SizedBox(
          height: 10,
        ),

       const Text('CONTACTO',
       style: TextStyle(
         fontSize: 15,
         fontWeight: FontWeight.bold,
         color: Colors.white,
       ),
       ),
       
     const SizedBox(
        height: 10,
      ),
         
        Container(
                      alignment: Alignment.center,
                     padding: const EdgeInsets.only(left: 15),
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Column(
                                children: [
                                  CupertinoButton(
                                    child: const Icon(Icons.facebook_outlined, color: Colors.pink,),
                                     onPressed: (){}
                                  ),
                                  const Text('Facebook', style: TextStyle(
                                    color: Colors.white,
                                  ),),
                                ],
                                
                              ),
                             
                             
                              const Spacer(),

                              Column(
                                children: [
                                  CupertinoButton(
                                    child: const Icon(Icons.mail_outline, color: Colors.pink,), onPressed: (){}
                                    ),
                                    const Text('Gmail', style: TextStyle(
                                      color: Colors.white,
                                    ),),
                                ],
                              ),
                              
                                

                              const Spacer(),
                             Container(
                               alignment: Alignment.centerRight,
                               child: Column(
                                
                                 children: [
                                   CupertinoButton(
                                     child: const Icon(Icons.mobile_screen_share_outlined,color: Colors.pink,), onPressed: (){}
                                     ),
                                     const Text('Tel', style: TextStyle(
                                       color: Colors.white,
                                     ),),
                                 ],
                               ),
                             ),
                             
                               

                              
                            ],
                          ),
                        ],
                      ),
                    ),

       ],
     ),
    );
  }
}