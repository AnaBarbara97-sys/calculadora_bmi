import 'package:calculadora_bmi1/assets/const.dart';
import 'package:calculadora_bmi1/widgets/reusable_card.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'drawer_info.dart';

class InputPage extends StatefulWidget{
  const InputPage({Key? key}) : super(key: key);

  @override
  _InputPageState createState() => _InputPageState();
}

class _InputPageState extends State<InputPage>{
  Color cardStatusColor = kInactiveCardColor;
  
  //Función que gestiona cuando la carta cambia de color
  void setStatusCard(){
    
  }

  @override
  Widget build(BuildContext context){
    final size = MediaQuery.of(context).size;
    return const Drawer();
  }
}

class Drawer extends StatelessWidget {
  const Drawer({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: const DrawerInfo(),
      appBar: AppBar(
        title: const Text('BMI Calculator'),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(
            child: Row(
              children: [
                Expanded(
                  child: TextButton(
                    onPressed: (){},
                    child: ReusableCard(
                      color: cardStatusColor,
                      widget: dataCardReusable(
                        icono: (FontAwesomeIcons.mars),
                        label: 'Masculino',
                      ),
                    ),
                  ),
                ),
                 Expanded(
                  child: TextButton(
                    onPressed: (){},
                    child: ReusableCard(
                      color: kActiveCardColor,
                      widget:dataCardReusable(
                        icono: (FontAwesomeIcons.venus),
                        label: 'Femenino'
                      )
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
           child: ReusableCard(
             color: kInactiveCardColor,
             widget: dataCardReusable(
               label: 'Estatura',
             ),  
           ),
           ),
         Expanded(
            child: Row(
              children: [
                Expanded(
                  child: ReusableCard(
                    color: kInactiveCardColor,
                    widget: dataCardReusable(),
                ),
                ),
                 Expanded(
                  child: ReusableCard(
                    color: kInactiveCardColor,
                    widget: dataCardReusable(),
                ),
                 ),
              ],
            ),
          ),
          Container(
            color: kBottonCardColor,
            margin: const EdgeInsets.all(10),
            width: double.infinity,
            height: kBottonCardHeight,
          ),
        ],
      ),
    );
  }
}

class dataCardReusable extends StatelessWidget {
  IconData? icono;
  String? label;

   dataCardReusable({
    Key? key,  
    this.icono,
    this.label,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Icon(icono, size: 45,
      color: Colors.white,),
      const SizedBox(
        height: 10,
      ),
      Text(label == null ? '' : label!.toString(),
      style: kCardStyle,
      ),
    ],
    );
  }
}

